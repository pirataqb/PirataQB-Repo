﻿Este Addon foi Desonvolvido pela equipa Pirataqb, para que todos possam disfrutar do seu conteudo.
Caso não goste das configurações do Addon, pode configurar no separador.
A equipa deseja-lhe uma boa sessão!