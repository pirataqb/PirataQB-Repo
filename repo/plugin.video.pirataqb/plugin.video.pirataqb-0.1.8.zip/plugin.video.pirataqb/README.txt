﻿Este [COLOR=red]Add[/COLOR][COLOR=blue]on[/COLOR] foi Desonvolvido pela equipa [COLOR=red]Pirata[/COLOR][COLOR=blue]qb[/COLOR], para que todos possam disfrutar do seu conteudo.
Caso não goste das configurações do [COLOR=red]Add[/COLOR][COLOR=blue]on[/COLOR], pode configurar no separador.
O Separador Séries será adicionado em Breve. A Pesquisa também será melhorada!
Qualquer duvida, sugestão ou reclamação contactar a equipa. Queremos que disfrute ao máximo da Plantaforma.
A equipa [COLOR=red]Pirata[/COLOR][COLOR=blue]qb[/COLOR] deseja-lhe uma boa sessão!