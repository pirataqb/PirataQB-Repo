﻿Este Addon foi Desonvolvido pela equipa Pirataqb, para que todos possam disfrutar do seu conteudo.
Caso não goste das configurações do Addon, pode configurar no separador.
Qualquer duvida, sugestão ou reclamação contactar a equipa. Queremos que disfrute ao máximo da Plantaforma.
A equipa deseja-lhe uma boa sessão!