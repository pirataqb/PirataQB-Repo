Este Addon foi Desonvolvido pela equipa Pirataqb, para que todos possam disfrutar do seu conteudo.
Caso n�o goste das configura��es do Addon, pode configurar no separador.
A equipa deseja-lhe uma boa sess�o!